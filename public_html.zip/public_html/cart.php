<?php
require "common.php";
if (isset($_SESSION['email'])) {
 header('location: products.php');
}
?>
<html>
    <head>
        <title>Cart</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.6.0.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link href="assignment2css.css" rel="stylesheet" type="text/css"/>
        </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php" class="navbar-brand">Lifestyle store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="cart.html" target="blank"><span class="glyphicon glyphicon-shopping-cart"></span>  Cart</a>
                    </li>
                    <li><a href="setting.html" target="blank"><span class="glyphicon glyphicon-user"></span>  Settings</a></li>
                    <li><a href="logout.html" target="blank"><span class="glyphicon glyphicon-log-out"></span>  Logout</a></li>
                </ul>
            </div>
      </div>
        </nav><br><br><br><br>
        <div class="container">
            <table class="table table-striped table-bordered">
                <tbody>
                    <tr><th>Item Number</th><th>Item Name</th><th>Price</th><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td>Total</td><td>Rs.0/-</td><td><a href="success.html" class="btn btn-primary"><button type="button" name="Confirm" class="btn btn-primary">Confirm Order</button></a></td></tr>
                </tbody>
            </table>
        </div><br><br>
        <footer>
                    <center>
                        <p>Copyright © Lifestyle Store. All Rights 
Reserved | Contact Us: +91 90000 00000</p>
                    </center>
        </footer>
    </body>
</html>
